from flask import render_template, request, send_from_directory
from app import app
from app.conexion import conectar
from app.notificar import enviar_telegram
from app.pdf_qr import generar_pdf_qr
import os

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        folio = request.form["folio"]
        nombre = request.form["nombre"]
        curp = request.form["curp"]
        estatus = request.form["estatus"]

        conn = conectar()
        cur = conn.cursor()
        cur.execute("INSERT INTO vehiculos (folio, nombre, curp, estatus) VALUES (%s, %s, %s, %s)",
                    (folio, nombre, curp, estatus))
        conn.commit()
        conn.close()

        generar_pdf_qr(folio, nombre, curp, estatus)
        enviar_telegram(f"Nuevo folio: {folio}")
        return "Documento registrado y QR generado"
    return render_template("formulario.html")

@app.route("/consulta")
def consulta():
    folio = request.args.get("folio")
    conn = conectar()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM vehiculos WHERE folio = %s", (folio,))
    row = cur.fetchone()
    conn.close()
    if row:
        return render_template("consulta.html", data=row)
    return "No encontrado", 404

@app.route("/static/docs/<filename>")
def docs_file(filename):
    return send_from_directory("static/docs", filename)

@app.route("/static/qrs/<filename>")
def qrs_file(filename):
    return send_from_directory("static/qrs", filename)
