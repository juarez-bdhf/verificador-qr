import mysql.connector

def conectar():
    return mysql.connector.connect(
        host="localhost",
        user="Brian juare",
        password="Hernandez2006",
        database="verificacion"
    )
