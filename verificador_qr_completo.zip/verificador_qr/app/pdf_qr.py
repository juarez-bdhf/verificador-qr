import qrcode
from fpdf import FPDF
import os

def generar_pdf_qr(folio, nombre, curp, estatus):
    os.makedirs("static/qrs", exist_ok=True)
    os.makedirs("static/docs", exist_ok=True)

    data = f"https://verificadorqr.duckdns.org/consulta?folio={folio}"
    qr = qrcode.make(data)
    qr_path = f"static/qrs/{folio}.png"
    qr.save(qr_path)

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, "SECRETARÍA DE ECONOMÍA", ln=1, align="C")
    pdf.cell(0, 10, "CERTIFICADO DE VERIFICACIÓN VEHICULAR", ln=1, align="C")
    pdf.ln(10)
    pdf.set_font("Arial", size=12)
    pdf.cell(0, 8, f"Folio: {folio}", ln=1)
    pdf.cell(0, 8, f"Nombre: {nombre}", ln=1)
    pdf.cell(0, 8, f"CURP: {curp}", ln=1)
    pdf.cell(0, 8, f"Estatus: {estatus}", ln=1)
    pdf.ln(10)
    pdf.image(qr_path, x=150, y=60, w=40)
    pdf.output(f"static/docs/{folio}.pdf")
