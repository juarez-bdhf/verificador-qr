# Sistema Verificador Vehicular con QR y PDF

Este sistema permite registrar documentos, generar códigos QR que enlazan a una consulta pública y descargar el documento oficial en PDF. Ideal para verificaciones de vehículos, certificados o facturas.

---

## 🧩 Requisitos

```bash
pip install -r requirements.txt
```

---

## ▶️ Cómo ejecutar localmente

1. Clona o descomprime este proyecto.
2. Asegúrate de tener un servidor MySQL y crea una base de datos llamada `verificacion` con la siguiente tabla:

```sql
CREATE TABLE vehiculos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  folio VARCHAR(100) UNIQUE,
  nombre VARCHAR(255),
  curp VARCHAR(100),
  estatus VARCHAR(100)
);
```

3. Edita `conexion.py` y pon tus credenciales reales de MySQL.
4. Corre el sistema:

```bash
python main.py
```

Abre [http://localhost:5000](http://localhost:5000)

---

## 🌐 Publicarlo gratis con Render

1. Ve a [https://render.com](https://render.com) y crea una cuenta.
2. Sube este proyecto a GitHub.
3. En Render, crea un nuevo servicio web:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python main.py`
   - **Python Version**: 3.10 o superior
4. Asegúrate de activar puertos y ambiente.

---

## 🆓 Usar dominio gratuito

Puedes usar [https://duckdns.org](https://duckdns.org) para tener un dominio gratis como:

```
https://verificadorqr.duckdns.org
```

---

## 🔔 Notificaciones por Telegram

1. Crea un bot en Telegram con [@BotFather](https://t.me/BotFather)
2. Copia el `BOT_TOKEN`
3. Obtén tu `CHAT_ID` desde el bot [@userinfobot](https://t.me/userinfobot)
4. Sustituye estos valores en `notificar.py`

---

## ✅ Resultado

- Acceso público al verificar documentos por QR
- Descarga de PDF oficial
- Estilo tipo SAT
